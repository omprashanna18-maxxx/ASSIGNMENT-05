
import statistics
import time
import random
from datetime import date, timedelta


random.seed(42)

# ==========================================
# GENERATE SAMPLE AIR QUALITY DATA
# ==========================================

stations = [
    "Adyar", "Anna Nagar", "Velachery", "Guindy",
    "T Nagar", "Nungambakkam", "Perungudi",
    "Tambaram", "Royapuram", "Kodambakkam",
    "Manali", "Alwarpet"
]

start_date = date(2026, 10, 1)

readings = []

for station in stations:

    for day in range(31):

        current_day = str(
            start_date + timedelta(days=day)
        )

        for hour in range(24):

            pm25 = round(random.uniform(20, 100), 1)

            readings.append(
                (station, current_day, pm25)
            )


# ==========================================
# METHOD 1: SQL GROUP BY SIMULATION
# ==========================================

t = time.perf_counter()

sql_groups = {}

for station, day, value in readings:

    key = (station, day)

    sql_groups.setdefault(key, []).append(value)

sql = {
    key: (
        min(values),
        max(values),
        round(statistics.mean(values), 6)
    )
    for key, values in sql_groups.items()
}

t_sql = time.perf_counter() - t


# ==========================================
# METHOD 2: PYTHON LOOPS
# ==========================================

t = time.perf_counter()

groups = {}

for station, day, value in readings:

    if value is not None:

        groups.setdefault(
            (station, day), []
        ).append(value)

loops = {
    key: (
        min(values),
        max(values),
        round(statistics.mean(values), 6)
    )
    for key, values in groups.items()
}

t_loops = time.perf_counter() - t


# ==========================================
# DISPLAY RESULTS
# ==========================================

print(
    f"SQL GROUP BY       : {len(sql)} groups in "
    f"{t_sql * 1000:.1f} ms"
)

print(
    f"Python loops       : {len(loops)} groups in "
    f"{t_loops * 1000:.1f} ms"
)

print(
    "Same min, max and mean for every group:",
    all(
        abs(a - b) < 1e-6
        for key in sql
        for a, b in zip(sql[key], loops[key])
    )
)
