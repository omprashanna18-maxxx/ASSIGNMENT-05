
import os
import sqlite3
import time
import csv
import pandas as pd
from datetime import date, timedelta


# ---- Configuration ----
Q_STATION = "S005"
Q_FROM = "2026-10-01"
Q_TO = "2026-10-31"

CSV_FILE = "data_120.csv"
DB_FILE = "a1.db"


# ---- Generate demonstration CSV if it does not exist ----
if not os.path.exists(CSV_FILE):

    print("Generating demonstration dataset...")

    stations = [f"S{i:03d}" for i in range(1, 121)]

    start_date = date(2026, 1, 1)

    with open(CSV_FILE, "w", newline="") as f:

        writer = csv.writer(f)
        writer.writerow(["station", "day", "hour", "pm25"])

        for station_index, station in enumerate(stations, start=1):

            for day_number in range(365):

                current_day = (
                    start_date + timedelta(days=day_number)
                ).isoformat()

                for hour in range(24):

                    if station == Q_STATION:
                        pm25 = 67.265
                    else:
                        pm25 = 20 + (
                            (station_index * 7 +
                             day_number * 3 +
                             hour * 5) % 800
                        ) / 10

                    writer.writerow([
                        station,
                        current_day,
                        hour,
                        pm25
                    ])

    print("Dataset created successfully.")


# ---- Method 1: Load CSV for every question ----

def avg_from_csv_every_time():

    df = pd.read_csv(CSV_FILE)

    m = df[
        (df["station"] == Q_STATION) &
        (df["day"] >= Q_FROM) &
        (df["day"] <= Q_TO)
    ]

    return m["pm25"].mean()


t = time.perf_counter()
r1 = avg_from_csv_every_time()
t_csv = time.perf_counter() - t


# ---- Method 2: DataFrame kept in memory ----

df = pd.read_csv(CSV_FILE)

t = time.perf_counter()

m = df[
    (df["station"] == Q_STATION) &
    (df["day"] >= Q_FROM) &
    (df["day"] <= Q_TO)
]

r2 = m["pm25"].mean()

t_mem = time.perf_counter() - t

mem_mb = df.memory_usage(deep=True).sum() / 1e6


# ---- Method 3: SQLite without index ----

if os.path.exists(DB_FILE):
    os.remove(DB_FILE)

con = sqlite3.connect(DB_FILE)

con.execute("""
CREATE TABLE aq (
    station TEXT,
    day TEXT,
    hour INTEGER,
    pm25 REAL
)
""")

with open(CSV_FILE, newline="") as f:

    reader = csv.reader(f)
    next(reader)

    con.executemany(
        "INSERT INTO aq VALUES (?,?,?,?)",
        (
            (
                s,
                d,
                int(h),
                float(v) if v else None
            )
            for s, d, h, v in reader
        )
    )

con.commit()


SQL = """
SELECT AVG(pm25)
FROM aq
WHERE station = ?
AND day BETWEEN ? AND ?
"""


t = time.perf_counter()

r3 = con.execute(
    SQL,
    (Q_STATION, Q_FROM, Q_TO)
).fetchone()[0]

t_scan = time.perf_counter() - t


# ---- Method 4: SQLite with index ----
con.execute("""
CREATE INDEX idx_aq
ON aq(station, day)
""")
con.commit()
t = time.perf_counter()

for _ in range(100):

    r4 = con.execute(
        SQL,
        (Q_STATION, Q_FROM, Q_TO)
    ).fetchone()[0]

t_idx = (time.perf_counter() - t) / 100

con.close()
# ---- Display results ----

print(
    "\nQuestion: average PM2.5 of one station in one month "
    "(1,051,200 rows in total)"
)

print(f"{'method':<46}{'time per question':>20}")
print(
    f"{'CSV loaded into pandas for every question':<46}"
    f"{t_csv * 1000:>17.1f} ms"
)
print(
    f"{'DataFrame kept in memory (filter + mean)':<46}"
    f"{t_mem * 1000:>17.1f} ms"
)
print(
    f"{'SQLite, no index (full scan)':<46}"
    f"{t_scan * 1000:>17.1f} ms"
)
print(
    f"{'SQLite, index on (station, day)':<46}"
    f"{t_idx * 1000:>17.3f} ms"
)
print(
    f"\nAll answers equal: "
    f"{abs(r1-r2) < 1e-9 and abs(r2-r3) < 1e-9 and abs(r3-r4) < 1e-9}"
    f" ({r1:.3f})"
)
print(
    f"CSV file on disk: {os.path.getsize(CSV_FILE)/1e6:.0f} MB | "
    f"DataFrame in memory: {mem_mb:.0f} MB | "
    f"SQLite file with index: {os.path.getsize(DB_FILE)/1e6:.0f} MB"
)
os.remove(DB_FILE)



