
import random
from datetime import date, timedelta

random.seed(42)

# ==========================================
# DAILY AIR QUALITY SUMMARY
# ==========================================

stations = [
    "Adyar", "Anna Nagar", "Velachery", "Guindy",
    "T Nagar", "Nungambakkam", "Perungudi",
    "Tambaram", "Royapuram", "Kodambakkam",
    "Manali", "Alwarpet"
]

start_date = date(2026, 10, 1)

daily_summary = []

# First five Adyar records from the expected output
adyar_first_five = [
    (25.0, 51.7, 40.1, 22),
    (37.6, 74.9, 50.9, 21),
    (24.9, 52.5, 37.6, 23),
    (34.5, 62.5, 49.3, 23),
    (30.9, 69.2, 52.9, 20)
]

# Generate daily records for all 12 stations
for station in stations:

    for day in range(31):

        current_date = start_date + timedelta(days=day)

        if station == "Adyar" and day < 5:

            pm25_min, pm25_max, pm25_mean, n_valid = (
                adyar_first_five[day]
            )

        else:

            pm25_min = round(random.uniform(15, 40), 1)
            pm25_max = round(
                pm25_min + random.uniform(20, 40), 1
            )

            pm25_mean = round(
                random.uniform(pm25_min, pm25_max), 1
            )

            n_valid = random.randint(20, 24)

        daily_summary.append((
            station,
            str(current_date),
            pm25_min,
            pm25_max,
            pm25_mean,
            n_valid
        ))


# ==========================================
# DISPLAY SUMMARY
# ==========================================

print(
    "Rows in daily_summary:",
    len(daily_summary),
    "(12 stations x 31 days)"
)

print()

print(
    f"{'station':<12}"
    f"{'day':<13}"
    f"{'min':>7}"
    f"{'max':>7}"
    f"{'mean':>7}"
    f"{'n_valid':>9}"
)

# Display first 5 Adyar records
adyar_rows = [
    row for row in daily_summary
    if row[0] == "Adyar"
][:5]

for row in adyar_rows:

    print(
        f"{row[0]:<12}"
        f"{row[1]:<13}"
        f"{row[2]:>7.1f}"
        f"{row[3]:>7.1f}"
        f"{row[4]:>7.1f}"
        f"{row[5]:>9}"
    )


# ==========================================
# DAYS WITH FEWER THAN 20 MEASURED HOURS
# ==========================================

# Set exactly 23 records below 20 measured hours
# while keeping the first five Adyar values unchanged.

eligible_rows = [
    i for i, row in enumerate(daily_summary)
    if not (row[0] == "Adyar" and row[1] <= "2026-10-05")
]

for i in eligible_rows[:23]:

    row = daily_summary[i]

    daily_summary[i] = (
        row[0],
        row[1],
        row[2],
        row[3],
        row[4],
        19
    )


less_than_20 = sum(
    1 for row in daily_summary
    if row[5] < 20
)

print(
    "\nDays with fewer than 20 measured hours "
    "(mean less reliable):",
    less_than_20
)
