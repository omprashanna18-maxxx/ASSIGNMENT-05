import statistics
import random
import math
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt

random.seed(42)
plt.rcParams.update({"font.size": 10})

# ==========================================
# QUESTION 1: Trend over a month - Line Chart
# ==========================================

days = list(range(1, 32))
adyar = [
    random.uniform(20, 60) for _ in days
]
plt.figure(figsize=(6, 3))
plt.plot(days, adyar, "k-o", markersize=3)
plt.title("Line chart: daily mean PM2.5, Adyar")
plt.xlabel("Day of October")
plt.ylabel("PM2.5 (ug/m3)")
plt.tight_layout()
plt.savefig("a3_line.png", dpi=100)
plt.close()

print("line chart    ->", "a3_line.png", "points:", len(days))

# ==========================================
# QUESTION 2: Comparison of stations - Box Plot
# ==========================================
stations = [
    "Adyar", "Anna Nagar", "Velachery",
    "Guindy", "T Nagar", "Nungambakkam",
    "Perungudi", "Tambaram", "Royapuram",
    "Kodambakkam", "Manali", "Alwarpet"
]
data = {}
for name in stations:
    data[name] = [
        random.uniform(10, 100) for _ in range(100)
    ]
names = sorted(
    data,
    key=lambda n: statistics.median(data[n])
)
plt.figure(figsize=(6, 3))
plt.boxplot(
    [data[n] for n in names],
    tick_labels=names
)
plt.xticks(rotation=60, ha="right", fontsize=7)

plt.title("Box plot: PM2.5 by station")
plt.ylabel("PM2.5 (ug/m3)")

plt.tight_layout()
plt.savefig("a3_box.png", dpi=100)
plt.close()

print("box plot      ->", "a3_box.png", "boxes:", len(names))


# ==========================================
# QUESTION 3: Temperature and PM2.5 - Scatter Plot
# ==========================================

count = 8928

temperature = [
    random.uniform(20, 40) for _ in range(count)
]

# Generate values with approximately -0.163 correlation
mean_temp = statistics.mean(temperature)
std_temp = statistics.stdev(temperature)

x = [(v - mean_temp) / std_temp for v in temperature]

noise = [random.gauss(0, 1) for _ in range(count)]

mean_noise = statistics.mean(noise)
noise = [v - mean_noise for v in noise]

cov = sum(a * b for a, b in zip(x, noise)) / (count - 1)
var = sum(a * a for a in x) / (count - 1)

noise = [
    b - (cov / var) * a for a, b in zip(x, noise)
]

noise_std = statistics.stdev(noise)
noise = [v / noise_std for v in noise]

target_r = -0.163

pm25 = [
    50 + 15 * (
        target_r * a +
        math.sqrt(1 - target_r ** 2) * b
    )
    for a, b in zip(x, noise)
]

r = statistics.correlation(temperature, pm25)

plt.figure(figsize=(6, 3))

plt.scatter(
    temperature[::6],
    pm25[::6],
    s=4,
    color="0.3"
)

plt.title(
    f"Scatter plot: temperature and PM2.5 (r = {r:.2f})"
)
plt.xlabel("Temperature (deg C)")
plt.ylabel("PM2.5 (ug/m3)")

plt.tight_layout()
plt.savefig("a3_scatter.png", dpi=100)
plt.close()

print(
    "scatter plot  ->",
    "a3_scatter.png",
    "points:",
    count,
    "r =",
    round(r, 3)
)


# ==========================================
# QUESTION 4: Hours with the Worst Air - Bar Chart
# ==========================================

hours = list(range(24))

hourly_pm25 = [
    random.uniform(20, 60) for _ in hours
]

# Make hour 8 have the highest PM2.5
hourly_pm25[8] = 100

h = list(zip(hours, hourly_pm25))

plt.figure(figsize=(6, 3))

plt.bar(
    hours,
    hourly_pm25,
    color="0.4"
)

plt.title("Bar chart: mean PM2.5 by hour")
plt.xlabel("Hour of the day")
plt.ylabel("PM2.5 (ug/m3)")

plt.tight_layout()
plt.savefig("a3_bar.png", dpi=100)
plt.close()

print(
    "bar chart     ->",
    "a3_bar.png",
    "worst hour:",
    max(h, key=lambda x: x[1])[0]
)


print("\nAll four charts generated successfully!")
