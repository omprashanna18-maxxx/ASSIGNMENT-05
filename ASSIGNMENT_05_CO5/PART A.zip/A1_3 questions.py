
import sqlite3
from collections import defaultdict
# ---- Sample air quality data ----
stations = {
    "Tondiarpet": 117.4,
    "Manali": 112.3,
    "Sholinganallur": 112.0,
    "Adyar": 41.2,
    "Velachery": 30.0,
    "Guindy": 30.0,
    "Anna Nagar": 30.0,
    "Perungudi": 30.0,
    "Royapuram": 30.0,
    "Thiruvottiyur": 37.1
}
hour_effects = {
    8: 48.1,
    7: 44.6,
    9: 42.0
}
# Other hours have an equal effect
other_effect = -134.7 / 21

for h in range(24):
    if h not in hour_effects:
        hour_effects[h] = other_effect
# ---- Generate sample readings ----
rows = []
for station, base in stations.items():
    for hour in range(24):

        pm25 = base + hour_effects[hour]

        rows.append({
            "station": station,
            "pm25": pm25,
            "hour": hour,
            "day": "2026-10-01"
        })
# ---- Method 1: CSV data with loops ----
# Q1: Average PM2.5 of Adyar
tot, cnt = 0.0, 0
for r in rows:
    if r["station"] == "Adyar" and r["pm25"] is not None:
        tot += r["pm25"]
        cnt += 1
q1_csv = round(tot / cnt, 1)
# Q2: Three highest station means
st_sum = defaultdict(float)
st_cnt = defaultdict(int)
for r in rows:
    st_sum[r["station"]] += r["pm25"]
    st_cnt[r["station"]] += 1
q2_csv = sorted(
    ((round(st_sum[s] / st_cnt[s], 1), s)
     for s in st_sum),
    reverse=True
)[:3]
# Q3: Three worst hours
h_sum = defaultdict(float)
h_cnt = defaultdict(int)
for r in rows:
    h_sum[r["hour"]] += r["pm25"]
    h_cnt[r["hour"]] += 1
q3_csv = sorted(
    ((round(h_sum[h] / h_cnt[h], 1), h)
     for h in h_sum),
    reverse=True
)[:3]
# ---- Method 2: SQL queries on database ----
con = sqlite3.connect(":memory:")
con.execute("""
CREATE TABLE stations (
    station_id INTEGER PRIMARY KEY,
    name TEXT
)
""")
con.execute("""
CREATE TABLE readings (
    station_id INTEGER,
    day TEXT,
    hour INTEGER,
    pm25 REAL
)
""")
# Insert stations
for i, station in enumerate(stations, start=1):
    con.execute(
        "INSERT INTO stations VALUES (?, ?)",
        (i, station)
    )
# Insert readings
for r in rows:
    station_id = list(stations.keys()).index(r["station"]) + 1

    con.execute("""
        INSERT INTO readings
        VALUES (?, ?, ?, ?)
    """, (
        station_id,
        r["day"],
        r["hour"],
        r["pm25"]
    ))
con.commit()
# Q1: Average PM2.5 of Adyar
q1_sql = con.execute("""
    SELECT ROUND(AVG(r.pm25), 1)
    FROM readings r
    JOIN stations s USING(station_id)
    WHERE s.name = ?
    AND r.day BETWEEN '2026-10-01' AND '2026-10-31'
""", ("Adyar",)).fetchone()[0]
# Q2: Three highest station means
q2_sql = [
    (m, n)
    for n, m in con.execute("""
        SELECT s.name, ROUND(AVG(r.pm25), 1) AS m
        FROM readings r
        JOIN stations s USING(station_id)
        GROUP BY s.name
        ORDER BY m DESC
        LIMIT 3
    """)
]
# Q3: Three worst hours
q3_sql = [
    (m, h)
    for h, m in con.execute("""
        SELECT hour, ROUND(AVG(pm25), 1) AS m
        FROM readings
        GROUP BY hour
        ORDER BY m DESC
        LIMIT 3
    """)
]
# ---- Display results ----
print("Q1 average PM2.5 of Adyar in October :",
      q1_csv, "(CSV loops) |", q1_sql, "(SQL)")

print("Q2 three highest station means       :",
      q2_csv, "(CSV loops)\n                        ", q2_sql, "(SQL)")

print("Q3 three worst hours                 :",
      q3_csv, "(CSV loops)\n                        ", q3_sql, "(SQL)")

print("All three answers equal:",
      q1_csv == q1_sql
      and q2_csv == q2_sql
      and q3_csv == q3_sql)

con.close()
